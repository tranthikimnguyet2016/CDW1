<?php
namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Nation extends Model
{
    protected $table = 'nations';
    protected $primaryKey = 'nation_id';

}