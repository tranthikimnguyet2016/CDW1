<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class FlightClass extends Model
{
    protected $table = 'flight_classes';
    protected $primaryKey = 'fc_id';

}