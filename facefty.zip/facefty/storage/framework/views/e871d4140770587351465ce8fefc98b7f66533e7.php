<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 col-md-push-3">
        <h2>Join as a Wordskills Travel Member</h2>
        <div class="panel panel-default">
            <div class="panel-body">
                <form role="form" action="<?php echo e(route('update')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php if(count($errors)>0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class='alert alert-danger'><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(session()->has('success')): ?>
                    <h1><?php echo e(session('success')); ?></h1>
                    <?php endif; ?>
                    <?php $__currentLoopData = $gInfor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label class="control-label">Email Address:</label>
                        <input name="user_email" id="user_email" type="email" value="<?php echo e($user->user_email); ?>" class="form-control" placeholder="Enter your email address" readonly>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Password:</label>
                        <input name="user_password" id="user_password" type="password" value="" class="form-control" placeholder="Enter your password">
                    </div>
                    <div classz="form-group">
                        <label class="control-label">First Name:</label>
                        <input name="user_first_name" id="user_first_name" type="text" value="<?php echo e($user->user_first_name); ?>" class="form-control" placeholder="Enter your name">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Last Name:</label>
                        <input name="user_last_name" id="user_last_name" type="text" value="<?php echo e($user->user_last_name); ?>" class="form-control" placeholder="Enter your name">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Phone Number:</label>
                        <input name="user_phone" id="user_phone" type="tel" value="<?php echo e($user->user_phone); ?>" class="form-control" placeholder="Enter your phone number">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-right">
                        <button type="submit" name="update" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>