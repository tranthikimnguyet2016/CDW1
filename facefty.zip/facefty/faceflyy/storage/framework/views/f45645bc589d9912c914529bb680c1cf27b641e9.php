<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>
<?php if(Session::get('login') == TRUE): ?>
    return redirect()->intended('/index');
<?php endif; ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 col-md-push-3">
        <h2>Log in to your account</h2>
        <div class="panel panel-default">
            <div class="panel-body">

                <form action="<?php echo e(url('login')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php if(count($errors)>0): ?>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <p class='alert alert-danger'><?php echo e($error); ?></p>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="form-group">
                        <label class="control-label">Email Address:</label>
                        <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>" autofocus placeholder="Enter your email address">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Password:</label>
                        <input type="password" name="password" class="form-control" placeholder="Enter your password">
                    </div>
                    <div class="text-right">
                        <button type="submit" name="login" class="btn btn-primary" value="Login">Log In</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>