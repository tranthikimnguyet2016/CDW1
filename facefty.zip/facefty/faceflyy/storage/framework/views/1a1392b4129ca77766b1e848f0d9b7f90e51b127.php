<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<main>
    <div class="container">
        <section>
            <h2>
                International Airlines
            </h2>
            <article>
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label class="control-label">ID</label>
                                    </div>
                                    <div class="col-sm-3">
                                        <label class="control-label">Nation</label>
                                    </div>
                                    <div class="col-sm-3">
                                        <label class="control-label">Airlines</label>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $nations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <div><big class="time"></big></div>
                                        <div><span class="place"><?php echo e($nation->nation_id); ?></span></div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div><big class="time"></big></div>
                                        <div><span class="place"><?php echo e($nation->nation_name); ?></span></div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div><big class="time"></big></div>
                                        <?php $__currentLoopData = $airlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($nation->nation_id == $airline->airline_nation_id): ?>
                                        <div><span class="place"><?php echo e($airline->airline_name); ?></span></div>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        </section>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>