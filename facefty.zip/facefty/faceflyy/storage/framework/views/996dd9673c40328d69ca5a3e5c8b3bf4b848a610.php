<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Flights - Worldskills Travel <?php echo $__env->yieldContent('title'); ?></title>
        <link rel="stylesheet" type="text/css" href="<?php echo asset ('template/assets/bootstrap/css/bootstrap.css'); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo asset ('template/assets/style.css'); ?>">

    </head>
    <body>
        <div class="wrapper">
            <?php $__env->startSection('sidebar'); ?>
            <header>
                <nav class="navbar-default navbar-static-top">
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-navbar">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a href="<?php echo e(route('index')); ?>" class="navbar-brand">Worldskills Travel</a>
                        </div>
                        <div class="collapse navbar-collapse" id="main-navbar">
                            <ul class="nav navbar-nav navbar-right">
                                <?php if(Session::get('login') == TRUE): ?>
                                <li><a href="#">Welcome <?php echo e(Session::get('user_first_name')); ?> <?php echo e(Session::get('user_last_name')); ?></a></li>
                                <?php else: ?>
                                <li><a href="#">Welcome message</a></li>
                                <?php endif; ?>
                                
                                <li><a href="<?php echo e(route('city-list')); ?>">City With Airport</a></li>
                                <li><a href="<?php echo e(route('airline-list')); ?>">International Airlines</a></li>

                                <li><a href="<?php echo e(route('index')); ?>">Flights</a></li>

                                <?php if(Session::get('login') == TRUE): ?> 
                                <li><a href="<?php echo e(route('logout')); ?>">Log Out</a></li>
                                <?php else: ?>
                                <li><a href="<?php echo e(route('login')); ?>">Log In</a></li>
                                <?php endif; ?>

                                <?php if(Session::get('login') == TRUE): ?>
                                <li><a href="<?php echo e(route('update')); ?>">Update</a></li>
                                <?php else: ?>
                                <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>
            <?php echo $__env->yieldSection(); ?>
            <main>
                <div class="container">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>
            <footer>
                <div class="container">
                    <p class="text-center">
                        Copyright &copy; 2017 | All Right Reserved
                    </p>
                </div>
            </footer>
        </div>
        <script type="text/javascript" src="<?php echo asset ('template/assets/jquery-3.2.1.min.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo asset ('template/assets/bootstrap/js/bootstrap.min.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo asset ('template/assets/bootstrap/js/bootstrap.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo asset ('template/assets/index.js'); ?>"></script>
    </body>
</html>