<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
    <h2>
        <?php $__currentLoopData = $citylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($city->city_id == $_GET['from']): ?>
        <?php echo e($city->city_name . " (". $city->city_code . ")"); ?>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <i class="glyphicon glyphicon-arrow-right"></i>
        <?php $__currentLoopData = $citylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($city->city_id == $_GET['to']): ?>
        <?php echo e($city->city_name. " (". $city->city_code . ")"); ?>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </h2>
   <?php $__currentLoopData = $flightlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flightlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <article>
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <h4><strong><a href="<?php echo e(route('flight-detail', ['fl_id'=>$flightlist->fl_id])); ?>"><?php echo e($flightlist->airline_name); ?></a></strong></h4>
                        <div class="row">
                            <div class="col-sm-3">
                                <?php $__currentLoopData = $citylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($citylist->city_id == $flightlist->fl_city_from_id): ?>
                                <label class="control-label">From:</label>
                                <div><big class="time"><?php echo e(date("H:i", strtotime($flightlist->fl_departure_day))); ?></big></div>
                                <div><span class="place"><?php echo e($citylist->city_name); ?></span></div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="col-sm-3">
                                <?php $__currentLoopData = $citylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($citylist->city_id == $flightlist->fl_city_to_id): ?>
                                <label class="control-label">To:</label>
                                <div><big class="time"><?php echo e(date("H:i", strtotime($flightlist->fl_return_day))); ?></big></div>
                                <div><span class="place"><?php echo e($citylist->city_name); ?></span></div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="col-sm-3">
                                <?php $__currentLoopData = $transits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($transit->transit_fl_id == $flightlist->fl_id): ?>
                                <label class="control-label">Duration:</label>
                                <div><big class="time"><?php echo e(date("H:i", strtotime($flightlist->fl_return_day) - strtotime($flightlist->fl_departure_day) )); ?></big></div>
                                <div><strong class="text-danger"><?php echo e($transit->count); ?> Transit</strong></div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="col-sm-3 text-right">
                                <h3 class="price text-danger"><strong>IDR <?php echo e($flightlist->fl_cost); ?></strong></h3>

                                <div>
                                    <a href="<?php echo e(route('flight-detail', ['fl_id'=>$flightlist->fl_id])); ?>" class="btn btn-link">See Detail</a>
                                    <a href="<?php echo e(route('flight-book')); ?>" id="checkReturn" class="btn btn-primary">Choose</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <div class="text-center">
        <ul class="pagination">
            <li><a href="#">&laquo;</a></li>
            <li><a href="#">&lsaquo;</a></li>
            <li class="active"><a href="#">1</a></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">&rsaquo;</a></li>
            <li><a href="#">&raquo;</a></li>
        </ul>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>