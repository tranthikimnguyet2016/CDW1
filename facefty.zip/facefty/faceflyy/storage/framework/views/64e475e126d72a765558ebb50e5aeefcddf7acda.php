<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section>
    <?php $__currentLoopData = $flightdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flightdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2>
        <?php $__currentLoopData = $citylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($city->city_id == $flightdetail->fl_city_from_id): ?>
        <?php echo e($city->city_name . " (". $city->city_code . ")"); ?>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <i class="glyphicon glyphicon-arrow-right"></i>
        <?php $__currentLoopData = $citylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($city->city_id == $flightdetail->fl_city_to_id): ?>
        <?php echo e($city->city_name. " (". $city->city_code . ")"); ?>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </h2>
    <article>
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <h4><strong><?php echo e($flightdetail->airline_name); ?></strong></h4>
                        <div class="row">
                            <div class="col-sm-3">
                                <label class="control-label">From:</label>
                                <div><big class="time"><?php echo e(date("H:i", strtotime($flightdetail->fl_departure_date))); ?></big></div>
                                <div><span class="place">
                                        <?php $__currentLoopData = $citylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($city->city_id == $flightdetail->fl_city_from_id): ?>
                                        <?php echo e($city->city_name . " (". $city->city_code . ")"); ?>

                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </span></div>
                            </div>
                            <div class="col-sm-3">
                                <label class="control-label">To:</label>
                                <div><big class="time"><?php echo e(date("H:i", strtotime($flightdetail->fl_landing_date))); ?></big></div>
                                <div><span class="place">
                                        <?php $__currentLoopData = $citylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($city->city_id == $flightdetail->fl_city_to_id): ?>
                                        <?php echo e($city->city_name. " (". $city->city_code . ")"); ?>

                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </span></div>
                            </div>
                            <div class="col-sm-3">
                                <label class="control-label">Duration:</label>
                                <div><big class="time"><?php echo e(date("H:i", strtotime($flightdetail->fl_landing_date) - strtotime($flightdetail->fl_departure_date) )); ?></big></div>
                                <div><strong class="text-danger">1 Transit</strong></div>
                            </div>
                            <div class="col-sm-3 text-right">
                                <h3 class="price text-danger"><strong>IDR<?php echo e($flightdetail->fl_cost); ?></strong></h3>
                                <div>
                                    <a href="<?php echo e(route('flight-book')); ?>" class="btn btn-primary">Choose</a>
                                </div>
                            </div>
                        </div>
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#flight-detail-tab">Flight Details</a></li>
                            <li><a data-toggle="tab" href="#flight-price-tab">Price Details</a></li>
                        </ul>
                        <div class="tab-content">
                            <div id="flight-detail-tab" class="tab-pane fade in active">
                                <ul class="list-group">
                                    <li class="list-group-item">
                                        <h5>
                                            <strong class="airline"><?php echo e($flightdetail->airline_name . " " . $flightdetail->fl_code); ?></strong>
                                            <p><span class="flight-class"><?php echo e(Session::get('fc_id')); ?></span></p>
                                        </h5>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <div><big class="time"><?php echo e(date("H:i", strtotime($flightdetail->fl_departure_date))); ?></big></div>
                                                        <div><small class="date"><?php echo e(date("d:m:y", strtotime($flightdetail->fl_departure_date))); ?></small></div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <?php $__currentLoopData = $citylists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($city->city_id == $flightdetail->fl_city_from_id): ?>
                                                        <div><span class="place"><?php echo e($city->city_name. " (". $city->city_code . ")"); ?></span></div>
                                                        <div><small class="airport"><?php echo e($city->airport_name); ?></small></div>
                                                        <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-1">
                                                <i class="glyphicon glyphicon-arrow-right"></i>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <div><big class="time">23:20</big></div>
                                                        <div><small class="date">29 Apr 2017</small></div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div><span class="place">Doha (DOH)</span></div>
                                                        <div><small class="airport">Doha Hamad International Airport</small></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-3 text-right">
                                                <label class="control-label">Duration:</label>
                                                <div><strong class="time">7h 35m</strong></div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item list-group-item-warning">
                                        <ul>
                                            <li>Transit for 1h 30m in Doha (DOH)</li>
                                        </ul>
                                    </li>
                                    <li class="list-group-item">
                                        <h5>
                                            <strong class="airline">Qatar Airways QR-1052</strong>
                                            <p><span class="flight-class">Economy</span></p>
                                        </h5>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <div><big class="time">00:50</big></div>
                                                        <div><small class="date">30 Apr 2017</small></div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div><span class="place">Doha (DOH)</span></div>
                                                        <div><small class="airport">Doha Hamad International Airport</small></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-1">
                                                <i class="glyphicon glyphicon-arrow-right"></i>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <div><big class="time">02:55</big></div>
                                                        <div><small class="date">30 Apr 2017</small></div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div><span class="place">Abu Dhabi (AUH)</span></div>
                                                        <div><small class="airport">Abu Dhabi Intl</small></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-3 text-right">
                                                <label class="control-label">Duration:</label>
                                                <div><strong class="time">2h 5m</strong></div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div id="flight-price-tab" class="tab-pane fade">
                                <h5>
                                    <strong class="airline">Qatar Airways</strong>
                                    <p><span class="flight-class">Economy</span></p>
                                </h5>
                                <ul class="list-group">
                                    <li class="list-group-item">
                                        <div class="pull-left">
                                            <strong>Passengers Fare (x3)</strong>
                                        </div>
                                        <div class="pull-right">
                                            <strong>IDR24.796.650,00</strong>
                                        </div>
                                        <div class="clearfix"></div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="pull-left">
                                            <span>Tax</span>
                                        </div>
                                        <div class="pull-right">
                                            <span>Included</span>
                                        </div>
                                        <div class="clearfix"></div>
                                    </li>
                                    <li class="list-group-item list-group-item-info">
                                        <div class="pull-left">
                                            <strong>You Pay</strong>
                                        </div>
                                        <div class="pull-right">
                                            <strong>IDR24.796.650,00</strong>
                                        </div>
                                        <div class="clearfix"></div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>